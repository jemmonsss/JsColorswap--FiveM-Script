fx_version 'cerulean'
game 'gta5'

author 'J_emmons_07'
description 'Color Fade (no dependencies, pure GTA menu)'

shared_script 'shared/config.lua'
client_script 'client/cl_main.lua'
server_script 'server/sv_main.lua'

lua54 'yes'
