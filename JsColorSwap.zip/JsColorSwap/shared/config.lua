Config = {}

-- Whitelisted player identifiers
Config.AllowedIdentifiers = {
    "license:733427143ead3ec06f6ac051e369d7f62f8ca90c",
    "license:abcdef1234567890"
}

-- Max GTA vehicle primary color index (from native docs, 160+ colors exist)
Config.MaxVehicleColors = 160